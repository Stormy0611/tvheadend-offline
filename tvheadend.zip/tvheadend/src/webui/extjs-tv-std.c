extjs_lcss(hq, "static/tvh-tv.css.gz");
extjs_load(hq, "redir/locale.js");
extjs_load(hq, "static/tvh-tv.js.gz");
