extjs_lcss(hq, "redir/theme.css");
extjs_load(hq, "redir/locale.js");
extjs_load(hq, "static/tvh.js.gz");
