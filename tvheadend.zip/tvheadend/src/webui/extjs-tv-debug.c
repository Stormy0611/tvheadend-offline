extjs_lcss(hq, "static/tv.css");
extjs_load(hq, "redir/locale.js");
extjs_load(hq, "static/extjs/adapter/ext/ext-base-debug.js");
 extjs_load(hq, "static/extjs/ext-all-debug.js");
 extjs_load(hq, "static/app/i18n.js");
 extjs_load(hq, "static/tv.js");
