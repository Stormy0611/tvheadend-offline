const char *tvheadend_version = "0.0.0~unknown";
