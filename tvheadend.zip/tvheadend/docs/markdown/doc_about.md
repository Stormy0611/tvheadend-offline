## About

This documentation forms part of the Tvheadend project.

All rights reserved, and all implications of using, following, not 
following, or in any way even being aware of this documentation are 
expressly excluded. Use everything entirely at your own risk. If your 
television explodes, your house burns down or your kittens end up in 
tears, that's nothing to do with us.

(c) 2006 - 2017 Tvheadend Foundation CIC

## Licensing

The entire project is currently licensed using [GPLv3](http://www.gnu.org/licenses/gpl-3.0.txt).

## Further Information

For more information regarding the project, licensing and contributions, please see:

[Project website](https://tvheadend.org)

[Contributor information](https://tvheadend.org/projects/tvheadend/wiki/Contributors)

[Contributor Licensing Agreement](https://tvheadend.org/projects/tvheadend/wiki/CLA)
