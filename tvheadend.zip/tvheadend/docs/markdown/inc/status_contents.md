Contents                                          | Description
--------------------------------------------------|------------------------
[Overview](#overview)                             | Tab overview
[Stream](status_stream)                           | Currently-active streams
[Subscriptions](status_subscriptions)             | Active subscriptions
[Connections](status_connections)                 | Connection information
[Service Mapper Dialog](class/service_mapper)     | Service mapping dialog
[Service Mapper](status_service_mapper)           | Service mapping status
[Items/Properties](#items)                        | Items/Properties
