**View Level**         | Change the interface view level to show/hide more advanced options.\n**Help**               | Display this help page.
