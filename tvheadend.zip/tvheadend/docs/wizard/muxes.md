**Assign Predefined Muxes to Networks**

To save you from manually entering muxes, Tvheadend includes predefined
mux lists. Please select an option from the list for each network.


Pre-defined lists are not always up-to-date, this generally 
isn't a problem provided that one of the muxes in list 
is active, and contains network information. 


**If you don't see any options below, you need to go back and assign a 
network type to a tuner.**
