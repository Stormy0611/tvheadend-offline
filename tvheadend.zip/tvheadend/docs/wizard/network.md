**Tuner and Network**

Now let's get your tuners configured. Go ahead and select a network for
each of the tuners you would like to use. If you don't assign a
network to a tuner it __won't__ be used.
